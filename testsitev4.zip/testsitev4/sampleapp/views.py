from django.shortcuts import render
from django.http import HttpResponse
from django.urls import reverse 
from sampleapp.models import Car
from sampleapp.models import Store

# Create your views here.
def home(request):
    return render(request, 'snippets/home_page.html')

def contact(request):
    error = False
    if 'city' in request.GET:
        city = request.GET['city']
        if not city:
            error = True
        else:
            stores = Store.objects.filter(pickup_store_city=city) 
            return render(request, 'snippets/contact_page.html', {'stores': stores, 'query': city})
    return render(request, 'snippets/contact_page.html', {'error' : error})

def customsearch(request):
    return render(request, 'snippets/customsearch_page.html')

def recommendedvehicles(request):
    return render(request, 'snippets/recommend_page.html')

def location(request):
    return render(request, 'snippets/location_page.html')

def searchresults(request):
    error = False
    if 'make' in request.GET:
        make = request.GET['make']
        model = request.GET['model']
        series = request.GET['series']
        year = str(request.GET['year'])
        capacity = str(request.GET['capacity'])
        transmission = request.GET['transmission']
        if not make:
            error = True
        else:
            cars = Car.objects.filter(car_makename__icontains=make, car_standardtransmission__icontains=transmission,
            car_model__icontains=model, car_series__icontains=series, car_seriesyear__icontains=year, car_seatingcapacity__icontains=capacity) 
            return render(request, 'snippets/searchresults.html', {'cars': cars, 'query': make})

    return render(request, 'snippets/customsearch_page.html', {'error': error})
    



