from django.test import TestCase
from sampleapp.models import Customers

# Create your tests here.

class MyTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        # Set up data for the whole TestCase
        Customers.objects.create(customer_name="Test")

    def test1(self):
        # Some test using self.foo
        test = Customers.objects.get(car_id=1)
        expected_object_name = test.customer_name
        self.assertEquals(expected_object_name, 'Test')

