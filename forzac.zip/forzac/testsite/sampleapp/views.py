from django.shortcuts import render
from django.http import HttpResponse
from django.urls import reverse 
from django.db.models import Count
from django.db.models import Sum
from sampleapp.models import Cars
from sampleapp.models import Stores
from sampleapp.models import Orders
from sampleapp.models import Carcurrentlocation
from sampleapp.models import Customers

# Create your views here.
def home(request):
    return render(request, 'snippets/home_page.html')

def contact(request):
    error = False
    if 'city' in request.GET:
        city = request.GET['city']
        if not city:
            error = True
        else:
            stores = Stores.objects.filter(pickup_store_city=city) 
            return render(request, 'snippets/contact_page.html', {'stores': stores, 'query': city})
    return render(request, 'snippets/contact_page.html', {'error' : error})

def customsearch(request):
    return render(request, 'snippets/customsearch_page.html')

def recommendedvehicles(request):
    error = False
    if 'location' in request.GET:
        location = request.GET['location']
        if not location:
            error = True
        else:
            results = Cars.objects.filter(car_type__icontains=location)
            return render(request, 'snippets/recommendedresults.html', {'results': results, 'query': location})
    return render(request, 'snippets/recommend_page.html', {'error' : error})

def location(request):
    error = False
    if 'city' in request.GET:
        location = request.GET['city']
        if not location:
            error = True
        else:
            results = Carcurrentlocation.objects.filter(return_store_city__icontains=location)
            # for x in results:
            #     cars = Cars.objects.filter(car_ID=results[x].car_ID)
            return render(request, 'snippets/locationresults.html', {'results': results, 'query': location})
    return render(request, 'snippets/location_page.html')

def analysis(request):
    allmonths = ["January", "Feburary", "March", "April", "May", "June", "July", "August", "September",
    "October", "November", "December"]

    error = False
    if 'month' in request.GET:
        month = request.GET['month']
        year = request.GET['year']

        if not month:
            error = True
        else:

            # query = Order.objects.all().query
            # query.group_by = ['Order_PickupStore']
            # results = QuerySet(query=query, model=Order)

            for x in range(11):
                if(allmonths[x] == month):
                    query = x
                    month = x+1
                    break
            
            if(month >= 10):
                month = str(month)
                date = year + "-" + month
            else:
                month = str(month)
                date = year + "-0" + month

            #.values() is basically GROUP BY
            results = Orders.objects.filter(order_pickupdate__startswith=date).values('order_pickupstore').annotate(num_orders=Count('order_pickupstore')).order_by('-num_orders')
            #results = Order.objects.annotate(num_books=Count(date))
            
            # if(month == 'September'):
            #     month = '9'
            orders = Orders.objects.filter(order_pickupdate__startswith=date)
            return render(request, 'snippets/analysis_results.html', {'orders': orders, 'query': allmonths[query], 'year': year, 'results': results})

    return render(request, 'snippets/analysis_page.html', {'error': error})

def storeanalysis(request):
    error = False

    if 'store' in request.GET:
        store = request.GET['store']

        if not store:
            error = True
        else:
            results2005 = Orders.objects.filter(order_pickupdate__startswith=2005, order_pickupstore=store).values('order_pickupstore').annotate(num_orders=Count('order_pickupstore'))
            results2006 = Orders.objects.filter(order_pickupdate__startswith=2006, order_pickupstore=store).values('order_pickupstore').annotate(num_orders=Count('order_pickupstore'))
            results2007 = Orders.objects.filter(order_pickupdate__startswith=2007, order_pickupstore=store).values('order_pickupstore').annotate(num_orders=Count('order_pickupstore'))
            return render(request, 'snippets/storeanalysisresults.html', {'results2005': results2005, 'results2006': results2006, 'results2007': results2007, 'error': error, 'store': store})

    return render(request, 'snippets/storeanalysis.html', {'error': error})

def leaderboard(request):

    results = Orders.objects.all().values('order_pickupstore').annotate(num_orders=Count('order_pickupstore')).order_by('-num_orders')

    return render(request, 'snippets/rankings.html', {'results': results})

def deals(request):
    allmonths = ["January", "Feburary", "March", "April", "May", "June", "July", "August", "September",
    "October", "November", "December"]

    error = False
    foundmonth = False

    if 'month' in request.GET:
        month = request.GET['month']

        if not month:
            error = True
        else:        
            for x in range(11):
                if(allmonths[x] == month):
                    query = x
                    month = x+1
                    foundmonth = True
                    break

            if foundmonth:
                results = Customers.objects.filter(customer_birthday__month=month)
            
                return render(request, 'snippets/dealresults.html', {'results': results, 'month': month, 'query': allmonths[query]})
            else:
                error = True
                

    return render(request, 'snippets/deals.html', {'error': error})

def mostusedvehicles(request):

    results = Orders.objects.all().values('car_id').annotate(num_orders=Count('car_id')).order_by('-num_orders')

    return render(request, 'snippets/mostusedvehicles.html', {'results': results})


def searchresults(request):
    error = False
    if 'make' in request.GET:
        make = request.GET['make']
        model = request.GET['model']
        series = request.GET['series']
        year = str(request.GET['year'])
        capacity = str(request.GET['capacity'])
        transmission = request.GET['transmission']
        if not make:
            error = True
        else:
            cars = Cars.objects.filter(car_makename__icontains=make, car_standardtransmission__icontains=transmission,
            car_model__icontains=model, car_series__icontains=series, car_seriesyear__icontains=year, car_seatingcapacity__icontains=capacity) 
            return render(request, 'snippets/searchresults.html', {'cars': cars, 'query': make})

    return render(request, 'snippets/customsearch_page.html', {'error': error})
    



