"""testsite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from . import views


app_name = 'CRC'
urlpatterns = [
    path('home/', views.home, name = 'home'),
    path('contact/', views.contact, name = 'contact'),
    path('customsearch/', views.customsearch, name = 'customsearch'),
    path('recommendedvehicles/', views.recommendedvehicles, name = 'recommendedvehicles'),
    path('location/', views.location, name = 'location'),
    path('analysis/', views.analysis, name = 'analysis'),
    path('storeanalysis/', views.storeanalysis, name = 'storeanalysis'),
    path('leaderboard/', views.leaderboard, name = 'leaderboard'),
    path('deals/', views.deals, name = 'deals'),
    path('mostusedvehicles/', views.mostusedvehicles, name = 'mostusedvehicles'),
    
    path('customsearch/searchresults/', views.searchresults, name = 'searchresults'),
]
