from django.shortcuts import render
from django.http import HttpResponse
from django.urls import reverse 

# Create your views here.
def home(request):
    return render(request, 'snippets/home_page.html')

def menu(request):
    return render(request, 'snippets/menu_page.html')

def contact(request):
    return render(request, 'snippets/contact_page.html')

