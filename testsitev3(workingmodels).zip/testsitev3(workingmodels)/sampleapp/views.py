from django.shortcuts import render
from django.http import HttpResponse
from django.urls import reverse 

# Create your views here.
def home(request):
    return render(request, 'snippets/home_page.html')

def contact(request):
    return render(request, 'snippets/contact_page.html')

def customsearch(request):
    return render(request, 'snippets/customsearch_page.html')

def recommendedvehicles(request):
    return render(request, 'snippets/recommend_page.html')

def location(request):
    return render(request, 'snippets/location_page.html')

