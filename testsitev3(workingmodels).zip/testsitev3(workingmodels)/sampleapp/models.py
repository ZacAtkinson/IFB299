from django.db import models

# Create your models here.

# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Cars(models.Model):
    car_id = models.IntegerField(db_column='Car_ID', primary_key=True)  # Field name made lowercase.
    car_makename = models.CharField(db_column='Car_MakeName', max_length=255, blank=True, null=True)  # Field name made lowercase.
    car_model = models.CharField(db_column='Car_Model', max_length=255, blank=True, null=True)  # Field name made lowercase.
    car_series = models.CharField(db_column='Car_Series', max_length=255, blank=True, null=True)  # Field name made lowercase.
    car_seriesyear = models.IntegerField(db_column='Car_SeriesYear', blank=True, null=True)  # Field name made lowercase.
    car_pricenew = models.IntegerField(db_column='Car_PriceNew', blank=True, null=True)  # Field name made lowercase.
    car_enginesize = models.CharField(db_column='Car_EngineSize', max_length=5, blank=True, null=True)  # Field name made lowercase.
    car_fuelsystem = models.CharField(db_column='Car_FuelSystem', max_length=255, blank=True, null=True)  # Field name made lowercase.
    car_tankcapacity = models.CharField(db_column='Car_TankCapacity', max_length=4, blank=True, null=True)  # Field name made lowercase.
    car_power = models.CharField(db_column='Car_Power', max_length=6, blank=True, null=True)  # Field name made lowercase.
    car_seatingcapacity = models.IntegerField(db_column='Car_SeatingCapacity', blank=True, null=True)  # Field name made lowercase.
    car_standardtransmission = models.CharField(db_column='Car_StandardTransmission', max_length=255, blank=True, null=True)  # Field name made lowercase.
    car_bodytype = models.CharField(db_column='Car_BodyType', max_length=255, blank=True, null=True)  # Field name made lowercase.
    car_drive = models.CharField(db_column='Car_Drive', max_length=255, blank=True, null=True)  # Field name made lowercase.
    car_wheelbase = models.CharField(db_column='Car_Wheelbase', max_length=255, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'cars'


class Customers(models.Model):
    customer_id = models.IntegerField(db_column='Customer_ID', primary_key=True)  # Field name made lowercase.
    customer_name = models.CharField(db_column='Customer_Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    customer_phone = models.CharField(db_column='Customer_Phone', max_length=255, blank=True, null=True)  # Field name made lowercase.
    customer_address = models.CharField(db_column='Customer_Address', max_length=255, blank=True, null=True)  # Field name made lowercase.
    customer_birthday = models.DateField(db_column='Customer_Birthday', blank=True, null=True)  # Field name made lowercase.
    customer_occupation = models.CharField(db_column='Customer_Occupation', max_length=255, blank=True, null=True)  # Field name made lowercase.
    customer_gender = models.CharField(db_column='Customer_Gender', max_length=1, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'customers'


class Orders(models.Model):
    order_id = models.IntegerField(db_column='Order_ID', blank=True, null=True)  # Field name made lowercase.
    customer_id = models.IntegerField(db_column='Customer_ID', primary_key=True)  # Field name made lowercase.
    car_id = models.IntegerField(db_column='Car_ID', blank=True, null=True)  # Field name made lowercase.
    order_createdate = models.DateField(db_column='Order_CreateDate')  # Field name made lowercase.
    order_pickupdate = models.DateField(db_column='Order_PickupDate', blank=True, null=True)  # Field name made lowercase.
    order_pickupstore = models.IntegerField(db_column='Order_PickupStore', blank=True, null=True)  # Field name made lowercase.
    order_returndate = models.DateField(db_column='Order_ReturnDate', blank=True, null=True)  # Field name made lowercase.
    order_returnstore = models.IntegerField(db_column='Order_ReturnStore', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'orders'
        unique_together = (('customer_id', 'order_createdate'),)


class Stores(models.Model):
    order_pickupstore = models.IntegerField(db_column='Order_PickupStore', primary_key=True)  # Field name made lowercase.
    pickup_store_name = models.CharField(db_column='Pickup_Store_Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    pickup_store_address = models.CharField(db_column='Pickup_Store_Address', max_length=255, blank=True, null=True)  # Field name made lowercase.
    pickup_store_phone = models.CharField(db_column='Pickup_Store_Phone', max_length=255, blank=True, null=True)  # Field name made lowercase.
    pickup_store_city = models.CharField(db_column='Pickup_Store_City', max_length=255, blank=True, null=True)  # Field name made lowercase.
    pickup_store_state_name = models.CharField(db_column='Pickup_Store_State_Name', max_length=16, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'stores'

